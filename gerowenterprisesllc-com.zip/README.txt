A Pen created at CodePen.io. You can find this one at http://codepen.io/MTaylorDaniels/pen/KWPGNO.

 Building website for Uncle's Irrigation Company, it's my first time